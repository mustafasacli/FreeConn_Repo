﻿namespace System.Turco
{
    public enum NsConnectionTypes : byte
    {
        SqlExpress = 0,
        SqlServer = 1,
        PostgreSql = 2,
        Oracle = 4,
        MySQL = 8
    };
}
